import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-booking_summary',
  templateUrl: 'booking_summary.html'
})
export class Booking_summaryPage {

  constructor(public navCtrl: NavController) {

  }

}


