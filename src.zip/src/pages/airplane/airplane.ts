import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-airplane',
  templateUrl: 'airplane.html'
})
export class AirplanePage {

  constructor(public navCtrl: NavController) {

  }

}
